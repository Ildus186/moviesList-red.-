import { Component } from 'react';
import './App.css';
import { Flex, Spin } from "antd";

import MoviesList from './Components/MoviesList/MoviesList';

export default class App extends Component {
  state = {
    data: [],
    totalMovies: null,
    isLoading: false,  
    error: null, 
    currentPage: 1,      
  };

  componentDidMount() {
    this.getData();
  }

  changePage = (page) => {
    this.setState({
      currentPage: page,
    },
    () => {this.getData()}
  );
  };

  getData = async () => {
    this.setState({ isLoading: true, error: null });  
    try {
      const { currentPage } = this.state;
      const response = await fetch(
        `https://api.themoviedb.org/3/search/movie?query=return&include_adult=false&language=en-US&page=${currentPage}`,
        {
          method: 'GET',
          headers: {
            Authorization:
              'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI5ZjM2ZjFmNmU1ZTUwMDBlMGRhMjExYjNmOThlYzNhZCIsIm5iZiI6MTc0NTI1NzMxMy44OTc5OTk4LCJzdWIiOiI2ODA2ODM2MTQyMWEzMDk3NWNhYWNhNzAiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.A-_NMdxuoMeRUwTAJHSoxI7pvyz4Swz1QRiwElvshBg',
          },
        }
      );

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const movies = await response.json();
      console.log(movies);
      this.setState({
        data: movies.results,
        totalMovies: movies.total_results,
        isLoading: false,  
      });
    } catch (error) {
      console.error('There was a problem fetching the data:', error);
      this.setState({
        error: error.message,  
        isLoading: false,       
      });
    }
  };

  render() {
    const { data, isLoading, error, currentPage, totalMovies } = this.state;

    if (isLoading) {
      return <div>Loading...</div>;  
    }

    if (error) {
      return <div>Error: {error}</div>;  
    }

    return (
      <>
        <MoviesList data={data} changePage={this.changePage} currentPage={currentPage} totalMovies={totalMovies} />
      </>
    );
  }
}
