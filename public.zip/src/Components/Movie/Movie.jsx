
import React, { Component } from 'react';
import { parse, format } from 'date-fns';
import { Pagination, Rate } from 'antd';

import './Movie.css';
import lenta from './lenta.png'



export default class Movie extends Component {

  changeDate = (date) => {
    if (date === "") return "The release date is unknown"
    const parsedDate = parse(date, 'yyyy-MM-dd', new Date());
    const formattedDate = format(parsedDate, 'MMMM d, yyyy');
    return formattedDate;
  };

  changeOverview = (string,start,end) => {
    if(string.length < start+1) return string;
    let foundIndex = -1;
    for (let i = start; i < end; i++){
      if(string[i] === " "){
       foundIndex = i;
       break
      }
    }
    const changeString = string.slice(0,foundIndex)
    return `${changeString} ...`
  }

  render() {
    const {
      other: { title, overview, poster_path, vote_average, release_date }
    } = this.props;

    const releaseDate = this.changeDate(release_date);
    const croppedText = this.changeOverview(overview,130,150);
    const croppedTitle = this.changeOverview(title,25,40);
    const voteAverage = vote_average.toFixed(1);

    const imageURL = `https://image.tmdb.org/t/p/original${poster_path}`

    // const timeAgo = formatDistanceToNow(created, { includeSeconds: true, addSuffix: true });

    return (
      <li>
        <div className='card'>
         <div className='posterBox'>
           <img className='poster' src = {poster_path ? imageURL : lenta} /> 
         </div>   
         <div className='content'>
          <div className="tittleBox">
            <h1 className='tittle'>{croppedTitle}</h1>
            <div className='vote'>{voteAverage}</div>
          </div>
          <p className='release'>{releaseDate}</p>
          <div className='genreBox'>
            <a className='genre'>Action</a>
            <a className='genre'>Drama</a>
          </div>
          <p className='overview'>{croppedText}</p>
          <Rate count={10} allowHalf style={{ fontSize: 16}} />
         </div>
        </div>
      </li>
    );
  }
}
