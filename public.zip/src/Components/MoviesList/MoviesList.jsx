import React, { Component } from 'react';
import { Pagination, } from 'antd';


import Movie from '../Movie/Movie';

import './MoviesList.css';


export default class MoviesList extends Component {
  

  render() {
    const { data, currentPage, changePage, totalMovies } = this.props;


    const elements = data.map((item) => {
      const { id, ...other } = item;
      return (
        <Movie
          key={id}
          other={other}
        />
      );
    });

    return (
      <>
     <ul className='list'>{elements}</ul>
     <Pagination align="center"
                current={currentPage}
                pageSize={data.length}
                onChange={changePage}
                total={totalMovies} />
     </>
    )
  }
}
